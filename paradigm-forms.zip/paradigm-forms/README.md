# Paradigm Forms
## Version 1.7.0
### Changelog
- Added dynamic from email function to add Paradigm @ current domain to mail
- Added and removed filters for mail sending
## Version 1.7.0
### Changelog
- Refactored the rest of plugin for standard use of wordpress settings
- Moved admin page html for entries to template
- Re-organized functions in files

## Version 1.6.0
### Changelog
- Refactored plugin for standardization
- Added csv functionality for forms and download button
- Added database functionality for all environments
- Removed css files and moved to theme for future updates
- Added a checkbox to show entries on the page